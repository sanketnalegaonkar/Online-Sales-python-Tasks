###This program defines a simulate_event function that takes a list of outcomes and their probabilities as input and 
# returns a simulated outcome based on the given probabilities. It then generates a sequence of outcomes for both the biased dice and coin and 
# prints the results. Note that due to the random nature of the simulation, the probability distribution may not exactly 
# match the specified biases, but it should be close over a large number of occurrences.
###



import random

def simulate_event(probabilities):
    total_probability = sum(prob[1] for prob in probabilities)
    
    # Normalize probabilities to ensure they sum up to 100
    normalized_probabilities = [(outcome, prob / total_probability) for outcome, prob in probabilities]
    
    # Generate a random number between 0 and 1
    random_number = random.uniform(0, 1)
    
    # Determine the outcome based on the given probabilities
    cumulative_probability = 0
    for outcome, prob in normalized_probabilities:
        cumulative_probability += prob
        if random_number <= cumulative_probability:
            return outcome

# Example 1: Rolling a biased six-faced dice
dice_probabilities = [(1, 10), (2, 30), (3, 15), (4, 15), (5, 30), (6, 0)]
dice_results = [simulate_event(dice_probabilities) for _ in range(1000)]

# Example 2: Flipping a biased coin
coin_probabilities = [("Head", 35), ("Tail", 65)]
coin_results = [simulate_event(coin_probabilities) for _ in range(1000)]

# Print the results
print("Dice Results:", dice_results)
print("Coin Results:", coin_results)
