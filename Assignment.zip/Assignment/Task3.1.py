#!/bin/bash
N=$1
if [ $N -lt 10 ]
then
        OUT=$((N*N))
elif [ $N -lt 20 ]
then
        OUT=1
        LIM=$((N - 10))
        for (( i=1; i<=$LIM; i++ ))  # Changed the loop condition to include $LIM
        do
                OUT=$((OUT * i))
        done
else
        LIM=$((N - 20))
        OUT=$((LIM * (LIM + 1) / 2))  # Corrected the calculation for sum of integers
fi
echo $OUT


###Changes made:

#In the loop condition of the second for loop, I changed i<$LIM to i<=$LIM to include the limit value in the loop.
#In the third block, I corrected the calculation for the sum of integers between 1 and (n-20).
###