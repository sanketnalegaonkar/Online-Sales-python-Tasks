def compute(n):
    if n < 10:
        out = n ** 2
    elif n < 20:
        out = 1
        for i in range(1, n - 10 + 1):  # Changed the loop condition to include n-10
            out *= i
    else:
        lim = n - 20
        out = lim * (lim + 1) // 2  # Corrected the calculation for sum of integers using // for integer division
    print(out)

n = int(input("Enter an integer: "))
compute(n)

###Changes made:

#In the loop condition of the second for loop, I changed range(1, n-10) to range(1, n-10+1) to include the limit value in the loop.
#Corrected the calculation for the sum of integers using // for integer division in the else block.
###